#!/bin/bash

echo "Running classifier.py..."
python3 fortune_cookie_classifier.py
