# %% Solve MPOPF
import os
import numpy as np
import pandas as pd
from collections import defaultdict

# Get the directory of the current file
current_file_dir = os.path.dirname(os.path.abspath(__file__))

# Change the current working directory to the directory of the current file
os.chdir(current_file_dir)

# Now you can proceed with the rest of your code
print(f"Current working directory: {os.getcwd()}")

# %%
from src.MultiPeriodDistOPF import *
# systemName = "ieee123_1ph"
systemName = "ads10_1ph"
T0 = 24
factor = 100 ## you can increase the length of training data set by increasing this factor
T = int(T0 * factor)
numAreas = 1
temporal_decmp = False
objfun0 = "subsPowerCostMin"
objfun2 = "scd"
inputForecastDescription = "bilevelCosts"
tSOC_hard = False
PSubsMax_kW = float('inf')
solver = "Ipopt"
# solver = "cyipopt"
# solver = "ipopt"

# %% Parse all data
data = parse_all_data(
    systemName,
    T,
    numAreas=numAreas,
    objfun0=objfun0,
    objfun2=objfun2,
    temporal_decmp=temporal_decmp,
    PSubsMax_kW=PSubsMax_kW,
    inputForecastDescription=inputForecastDescription,
    solver=solver,
    tSOC_hard=tSOC_hard
)


# %% Solve the model 
modelDict = optimize_MPOPF_1ph_NL_TemporallyBruteforced(data)
verbose = False
modelDict = compute_output_values(modelDict, verbose=verbose)
model = modelDict['model']
data = modelDict['data']
solution = modelDict['modelVals'] ## this gives solution of variables after optimization 

# %% creating a training dataframe with nodes and outputs
# Group values by nodes 
def group_by(data):
    grouped = defaultdict(list)
    for (node, time), value in data.items():
        grouped[node].append((time, value))
    return grouped

grouped_v = group_by(solution['v'])
grouped_b = group_by(solution['B'])
grouped_load = group_by(data['p_L_pu'])
grouped_pv = group_by(data['p_D_pu'])
# %% creating a training dataframe with inputs profiles and outputs
training_data = pd.DataFrame({
    'b': [value for battery in data['Bset'] for _, value in grouped_b[battery]],
    'volt': [value for battery in data['Bset'] for _, value in grouped_v[battery]],
    'load_prof': list(data['LoadShapeLoad']),
    'pv_prof': list(data['LoadShapePV']),
    'cost_prof': list(data['LoadShapeCost']),
    'net': [dis - ch for dis, ch in zip(solution['P_d'].values(), solution['P_c'].values())]
})


# Save to a CSV file
training_data.to_csv("Dagger_Dataset.csv", index=False)

print("Dagger dataset saved to a csv file")