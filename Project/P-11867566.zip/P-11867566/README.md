## How to run?
-setup the environment according to `conda-environment-setup.txt`.
-run expert.py to solve the expert (multi-period optimization) and to generate the required dataset for dagger.
-The dagger implementation is done in dagger.py
-generated plots are inside the plots folder


Environment configuration, Windows PC:
* Anaconda3 distribution (https://www.anaconda.com/)
* python ver 3.9.18 (may upgrade to 3.10)
* more to come...*

Additional packages (install via pip or local conda):
* opendssdirect-py 0.9.4 (latest stable)
* numpy 1.26.3
* pandas 1.5.3
* more to come...*

Optional packages:
* more to come...*

## FAQ:
### Filename too long error?
Based on this [stackoverflow]([url](https://stackoverflow.com/questions/22575662/filename-too-long-in-git-for-windows)) question's first answer, just open GitBash as an administrator and type in: <br>
`git config --global core.longpaths true`
