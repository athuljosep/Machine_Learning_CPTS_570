import tensorflow as tf
from keras import layers
from keras import optimizers
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
 
# Load and preprocess data
steps = 1
 
# Load dataset
dataset = pd.read_csv("Dagger_Dataset.csv")

# Shuffle the dataset to ensure randomness
dataset = dataset.sample(frac=1, random_state=42).reset_index(drop=True)
 
# Initialize scalers
input_scaler = MinMaxScaler()
output_scaler = MinMaxScaler()
 
dataset_input_features = ['b', 'volt', 'load_prof', 'pv_prof', 'cost_prof']
dataset_inputs_normalized = input_scaler.fit_transform(dataset[dataset_input_features])
 
dataset_output_features = ['net']
dataset_outputs_normalized = output_scaler.fit_transform(dataset[dataset_output_features])
 
dataset_inputs_tensors = tf.convert_to_tensor(dataset_inputs_normalized)
dataset_outputs_tensors = tf.convert_to_tensor(dataset_outputs_normalized)
 
# Split data
training_size = 0.6
testing_size = 0.2
validation_size = 0.1
prediction_size = 0.1
split_train = int(training_size * len(dataset))
split_test = split_train + int(testing_size * len(dataset))
split_validation = split_test + int(validation_size * len(dataset))

# Split data into tensors
training_inputs_tensors = dataset_inputs_tensors[:split_train]
training_outputs_tensors = dataset_outputs_tensors[:split_train]

testing_inputs_tensors = dataset_inputs_tensors[split_train:split_test]
testing_outputs_tensors = dataset_outputs_tensors[split_train:split_test]

validation_inputs_tensors = dataset_inputs_tensors[split_test:split_validation]
validation_outputs_tensors = dataset_outputs_tensors[split_test:split_validation]

prediction_inputs_tensors = dataset_inputs_tensors[split_validation:]
prediction_outputs_tensors = dataset_outputs_tensors[split_validation:]
 
def train_NN_Model(training_inputs_tensors, training_outputs_tensors, model=None, epochs=100):
    if model is None:
        model = tf.keras.Sequential([
            layers.InputLayer(input_shape=(training_inputs_tensors.shape[1],)),
            layers.Dense(64, activation='gelu'),
            layers.Dense(32, activation='gelu'),
            layers.Dense(1, activation=None)
        ])
        model.compile(
            optimizer=optimizers.Adam(learning_rate=1e-4),
            loss='mean_squared_error',
            metrics=['mae', 'mse']
        )
 
    history = model.fit(
        training_inputs_tensors, training_outputs_tensors,
        epochs=epochs,
        batch_size=24,
        verbose=0
    )
    return model, history
 
def get_NN_prediction(trained_model, testing_inputs):
    return trained_model.predict(testing_inputs, verbose=0)
 
def evaluate_NN(trained_model, testing_inputs, testing_outputs):
    return trained_model.evaluate(testing_inputs, testing_outputs, verbose=0)
 
# Initial Training
initial_epochs = 150
trained_model, trained_history = train_NN_Model(training_inputs_tensors, training_outputs_tensors, epochs=initial_epochs)
 
# DAgger Algorithm Loop
max_iterations = len(testing_outputs_tensors)
# max_iterations = 5
retraining_epochs = 50  # Fewer epochs for retraining
improvement_threshold = 1e-4
 
# Tracking metrics
test_losses = []
test_maes = []
test_mses = []
β_0 = 1.0  # Start fully relying on the expert
decay_factor = 0.9  # Exponential decay factor
 
for i in range(max_iterations):
    print(f"Starting iteration {i + 1}")
    new_states = testing_inputs_tensors[int(steps * i):int(steps * (i + 1))]
    learned_predictions = get_NN_prediction(trained_model, new_states)
    expert_outputs = testing_outputs_tensors[int(steps * i):int(steps * (i + 1))]
 
    # Aggregate new data
    aggregated_data_input = tf.concat([training_inputs_tensors, new_states], axis=0)
    aggregated_data_output = tf.concat([training_outputs_tensors, expert_outputs], axis=0)
 
    training_inputs_tensors = aggregated_data_input
    training_outputs_tensors = aggregated_data_output
 
    trained_model, trained_history = train_NN_Model(training_inputs_tensors, training_outputs_tensors, model=trained_model, epochs=retraining_epochs)
 
    test_loss, test_mae, test_mse = evaluate_NN(trained_model, validation_inputs_tensors, validation_outputs_tensors)
    test_losses.append(test_loss)
    test_maes.append(test_mae)
    test_mses.append(test_mse)

 
best_iteration = np.argmin(test_losses)
print(f"Best policy is from iteration {best_iteration + 1} with:")
print(f"Loss: {test_losses[best_iteration]}, MAE: {test_maes[best_iteration]}, MSE: {test_mses[best_iteration]}")

## now getting the prediction and actual of prediction/unseen data
unseen_predicted = get_NN_prediction(trained_model,prediction_inputs_tensors)
loss, mae, mse = evaluate_NN(trained_model, prediction_inputs_tensors, prediction_outputs_tensors)
print(f"Prediction Loss:{loss}")
print(f"fPrediction MAE:{mae}")
print(f"Prediction MSE:{mse}")
unseen_actual = prediction_outputs_tensors

## inverse transformation to bet the data in p.u.
unseen_predicted_pu = output_scaler.inverse_transform(unseen_predicted)
unseen_actual_pu = output_scaler.inverse_transform(unseen_actual)

# Example data (replace with actual predictions and outputs from your code)
KVA_B = 1000
learned_predictions_pu = unseen_predicted_pu.flatten() * KVA_B
actual_predictions_pu = unseen_actual_pu.flatten() * KVA_B

# Batch size
batch_size = 24

# Ensure the lengths match
assert len(learned_predictions_pu) == len(actual_predictions_pu), "Data lengths must match!"

# Number of batches
num_batches = len(learned_predictions_pu) // batch_size

# Plotting
# Directory to save plots
save_dir = "plots"
os.makedirs(save_dir, exist_ok=True)
for batch in range(num_batches):
    # Indices for the current batch
    start_idx = batch * batch_size
    end_idx = start_idx + batch_size

    # Extract batch data
    batch_actual = actual_predictions_pu[start_idx:end_idx]
    batch_predicted = learned_predictions_pu[start_idx:end_idx]
    indices = np.arange(batch_size)

    # Bar width
    bar_width = 0.35

    # Plotting
    plt.figure(figsize=(12, 6))
    plt.bar(indices - bar_width/2, batch_actual, bar_width, label='Actual', color='blue', alpha=0.7)
    plt.bar(indices + bar_width/2, batch_predicted, bar_width, label='Predicted', color='orange', alpha=0.7)

    # Add labels, title, and legend
    plt.xlabel('Sample Index in Batch', fontsize=12)
    plt.ylabel('Values (PU)', fontsize=12)
    plt.title(f'Comparison of Actual vs Predicted Values for Batch {batch + 1}', fontsize=14)
    plt.xticks(indices, labels=[f'DP {i+1}' for i in range(batch_size)], rotation=45)
    plt.legend(fontsize=12)
    plt.tight_layout()
    plt.grid(axis='y', linestyle='--', alpha=0.6)

    # # Show plot
    # plt.show()

    # Save plot
    plot_path = os.path.join(save_dir, f'batch_{batch + 1}.png')
    plt.savefig(plot_path)
    plt.close()

 
# Plot metrics
def plot_metrics(metric_values, metric_name):
    plt.figure(figsize=(8, 6))
    plt.plot(metric_values, marker='o', label=f'Test {metric_name}')
    plt.title(f'Test {metric_name} Over DAgger Iterations', fontsize=16)
    plt.xlabel('DAgger Iteration', fontsize=14)
    plt.ylabel(metric_name, fontsize=14)
    plt.legend(fontsize=12)
    plt.grid()
    plt.tight_layout()
    # plt.show()

    # Save plot
    plot_path = os.path.join(save_dir, f'{metric_name.lower()}_dagger_iterations.png')
    plt.savefig(plot_path)
    plt.close()
 
plot_metrics(test_losses, 'Loss')
plot_metrics(test_maes, 'MAE')
plot_metrics(test_mses, 'MSE')
 
# Save final model
trained_model.save("best_dagger_policy_model.h5")