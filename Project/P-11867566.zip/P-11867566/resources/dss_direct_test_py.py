# %%
"""
DGlover
MTPMPC-RL DSS Direct Test Script - Pair with .dss master folder
Add in dss.Storage module and check balanced dss config (Aryan)
X: input data (net load) --> replace with Storage control action
Y: output data (power flow solution)
"""
from builtins import any
import math as m
from pathlib import Path  # recommended for generating platform independent paths
import random as rd
import pandas as pd
import numpy as np
import opendssdirect as dss
from opendssdirect.utils import run_command


# %%
# fix issue with pandas
data_path = Path("./data/supplied-by-daniel/123Bus")
master_path = data_path / "IEEE123Master.dss"

# Convert the Path object to a string with the correct format for OpenDSS
master_path_str = str(master_path.resolve())

import warnings
warnings.filterwarnings("ignore", message="iteritems is deprecated")
# dss_path = r'E:\OpenDSS\123Bus\IEEE123Master.dss'
# dss_path = r"E:\OpenDSS\123Bus\IEEE123Master.dss"

# data_path = r'E:\OpenDSS'
# data_path = r'./data/supplied-by-daniel/123Bus/'

# master_path = data_path + r'IEEE123Master.dss'
# init
num_steps_D1 = 24  # one day
sw_num_D1 = 12  # flip switch at 12th hour
step_size = 60
Sbase = 1e6
num_pvs = 20
# pv_loads = rd.sample(dss.Loads.AllNames(), num_pvs)  # select num random loads for PV locations
pv_loads = ['s106b', 's109a', 's11a', 's87b', 's66c', 's85c', 's53a', 's71a', 's49c', 's30c', 's83c', 's47',
            's59b', 's64b', 's75c', 's98a', 's35a', 's28a', 's100c', 's37a']

##%%
def load123bus():
    dss.Text.Command('ClearAll')
    # run_command("Compile 'E:\\OpenDSS\\123Bus\\IEEE123Master.dss'")
    # Use the path in the run_command function
    run_command(f"Redirect '{master_path_str}'")
    dss.Loads.Status(3)  # response to load mult
    dss.Text.Command('set ControlMode=OFF')  # disable vreg, cap banks, etc for voltage swing
    dss.Text.Command('solve')  # solve ss circuit

##%%

def disableCaps():
    for cap in dss.Capacitors.AllNames():
        dss.Circuit.SetActiveElement('Capacitor.' + cap)
        dss.CktElement.Enabled(0)

## %%

## get PV time series irrad data
def importPVData():
    # mypvdata = pd.read_csv(data_path + r'\27MW_PV_5Min.csv', parse_dates=['LocalTime'], index_col=['LocalTime'])
    mypvdata = pd.read_csv(data_path / '27MW_PV_5Min.csv', parse_dates=['LocalTime'], index_col=['LocalTime'])
    mypvdata = mypvdata.resample("60min").asfreq()
    mypvdata = mypvdata.interpolate(method='linear')
    mypvdata.drop(mypvdata.tail(1).index, inplace=True)
    data = mypvdata['2006-05-01':'2006-05-01']  # 1 day
    data = data.reset_index(drop=True)
    df_scaled = data.copy()
    column = 'Power(kW)'
    df_scaled[column] = df_scaled[column] / df_scaled[column].abs().max()
    pv_time_series = df_scaled[["Power(kW)"]].to_numpy()
    return pv_time_series

##%%

def buildXYs():
    # PV For Pmpp at 25 deg celcius max efficiency
    run_command('New XYCurve.power_temp')
    temp_xarr = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
    power_yarr = np.array([1.04, 1.03, 1.02, 1.01, 1.01, 1.0, 0.99, 0.97, 0.89, 0.8, 0.75, 0.7, 0.65])
    dss.XYCurves.Npts(13)
    dss.XYCurves.XArray(temp_xarr)
    dss.XYCurves.YArray(power_yarr)

    # PV efficiency curve (all PVs)
    run_command('New XYCurve.PV_eff')
    eff_xarr = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    eff_yarr = np.array([0.75, 0.78, 0.8, 0.83, 0.86, 0.89, 0.93, 0.95, 0.97, 0.99])
    dss.XYCurves.Npts(10)
    dss.XYCurves.XArray(eff_xarr)
    dss.XYCurves.YArray(eff_yarr)

##%%

def assignLoadShapes():
    count = 1
    for name in dss.Loads.AllNames():
        dss.Loads.Name(name)  # activate load
        if count == 1:
            dss.Loads.Daily('lshape_1')
        elif count == 2:
            dss.Loads.Daily('lshape_2')
        else:
            dss.Loads.Daily('lshape_3')
            # reset counter
        if count > 3:
            count = 1
        else:
            count += 1

##%%

def upSampleLoadShapesAndTemps(df):
    df['LocalTime'] = pd.to_datetime(df['LocalTime'])  # interp misses last hour of data set!
    df.set_index('LocalTime', inplace=True)
    df = df.resample('60min').asfreq()
    df = df.interpolate(method='linear')
    df = df['2006-05-01':'2006-05-01']  # 1 day
    df = df.reset_index(drop=True)
    return df

##%%

def buildLoadshapes(pv_time_series):
    # loadshape1 = pd.read_csv(data_path + r'\Loadshape1.csv', parse_dates=True)
    # loadshape2 = pd.read_csv(data_path + r'\Loadshape2.csv', parse_dates=True)
    # loadshape3 = pd.read_csv(data_path + r'\Loadshape3.csv', parse_dates=True)

    loadshape1_path = data_path / 'Loadshape1.csv'
    loadshape2_path = data_path / 'Loadshape2.csv'
    loadshape3_path = data_path / 'Loadshape3.csv'

    # Read the CSV files using the updated paths
    loadshape1 = pd.read_csv(loadshape1_path, parse_dates=True)
    loadshape2 = pd.read_csv(loadshape2_path, parse_dates=True)
    loadshape3 = pd.read_csv(loadshape3_path, parse_dates=True)

    loadshape1_summer = upSampleLoadShapesAndTemps(loadshape1)
    loadshape2_summer = upSampleLoadShapesAndTemps(loadshape2)
    loadshape3_summer = upSampleLoadShapesAndTemps(loadshape3)

    loadshape_1 = loadshape1_summer.to_numpy()
    loadshape_2 = loadshape2_summer.to_numpy()
    loadshape_3 = loadshape3_summer.to_numpy()

    run_command('New Loadshape.lshape_1')
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_1)
    dss.LoadShape.QMult(loadshape_1)

    run_command('New Loadshape.lshape_2')
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_2)
    dss.LoadShape.QMult(loadshape_2)

    run_command('New Loadshape.lshape_3')
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_3)
    dss.LoadShape.QMult(loadshape_3)

    # PV loadshape
    run_command('New Loadshape.irrad')
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(pv_time_series)

##%%

def buildTempCurves():
    # pv_temps_hourly_year = pd.read_csv(data_path + r'\dallas_tx_pv_temp_60min.csv', parse_dates=True)
    # Construct the full path for the CSV file using pathlib
    pv_temps_hourly_year_path = data_path / 'dallas_tx_pv_temp_60min.csv'

    # Read the CSV file using the updated path
    pv_temps_hourly_year = pd.read_csv(pv_temps_hourly_year_path, parse_dates=True)

    pv_temp_summer = upSampleLoadShapesAndTemps(pv_temps_hourly_year)
    pv_temp_arr = pv_temp_summer.to_numpy()
    pv_temp = np.transpose(pv_temp_arr)
    return pv_temp

##%%

#  convert strings in bus names to node numbers for pv installation
def convertchars(pv_buses):
    buses = []
    for load in pv_buses:
        if 's' in load:
            load = load.replace('s', '')
        else:
            pass
        if 'a' in load:
            load = load.replace('a', '.1')
            buses.append(load)
        elif 'b' in load:
            load = load.replace('b', '.2')
            buses.append(load)
        elif 'c' in load:
            load = load.replace('c', '.3')
            buses.append(load)
        else:
            buses.append(load)
    return buses

##%%

#  create random pvs at bus locations, set to pf=0.95 for Q injs
def createPVs(pvloads, loadsdf):
    loads = convertchars(pvloads)
    for pvload, load in zip(pvloads, loads):
        for index, row in loadsdf.iterrows():
            if pvload == index:
                kV = row.kV
                pv_size = rd.uniform(0.9, 1.4)
                kVA = round((row.kVABase * pv_size), 5)
                Pmpp = round((kVA * 0.95), 5)  # 95% rated real power
                if load.isnumeric():
                    phases = 3
                else:
                    phases = 1
                run_command('New PVSystem.pv' + pvload + ' phases=' + str(phases) + ' bus1=' + load + ' kV=' + str(kV) +
                            ' kVA=' + str(kVA) + ' irradiance=1 Pmpp=' + str(Pmpp) + ' conn=wye temperature=25 PF=0.95'
                            ' effcurve=PV_eff P-TCurve=power_temp Daily=irrad TDaily=temp %cutin=0.05 %cutout=0.05')
            else:
                pass


# add monitors if needed
# def monitors():
#     for load in dss.Loads.AllNames():
#         run_command('New Monitor.' + load)
#         dss.Monitors.Element('Load.' + load)
#         dss.Monitors.Terminal(1)  #  phase a
#         dss.Monitors.Mode(1)  # powers (all phases)
#         run_command('~ ppolar=no')
#         # dss.Monitors.FileName(training_data)
#
#     for pv in dss.PVsystems.AllNames():
#         run_command('New Monitor.' + pv)
#         dss.Monitors.Element('PVSystem.' + pv)
#         dss.Monitors.Terminal(1)
#         dss.Monitors.Mode(1)  # powers
#         run_command('~ ppolar=no')
#         # dss.Monitors.FileName(training_data)
#
#     for line in dss.Lines.AllNames():
#         run_command('New Monitor.' + line)
#         dss.Monitors.Element(('Line.' + line))
#         dss.Monitors.Terminal(1)
#         dss.Monitors.Mode(1)  # powers
#         run_command('~ ppolar=no')

##%%

def createSwitchControl():
    # configure random set of 5 sw ctrls
    dss.Text.Command('New swtcontrol.sw2 SwitchedObj=line.sw2 SwitchedTerm=1')
    dss.Text.Command('New swtcontrol.sw4 SwitchedObj=line.sw4 SwitchedTerm=1')
    dss.Text.Command('New swtcontrol.sw5 SwitchedObj=line.sw5 SwitchedTerm=1')
    dss.Text.Command('New swtcontrol.sw7 SwitchedObj=line.sw7 SwitchedTerm=1')
    dss.Text.Command('New swtcontrol.sw8 SwitchedObj=line.sw8 SwitchedTerm=1')

##%%

# build circuit with DERs
def run123bus(pv_load_locations):
    pv_data = importPVData()
    load123bus()
    loads_dataframe = dss.utils.loads_to_dataframe()
    buildXYs()
    buildLoadshapes(pv_data)
    assignLoadShapes()
    pv_temp = buildTempCurves()

    # Assuming pv_temp is a nested list, flatten it
    # For example, if pv_temp is [[15, 15, 20, 30]], you want [15, 15, 20, 30]
    if isinstance(pv_temp, list) and len(pv_temp) == 1:
        pv_temp = pv_temp[0]  # Flatten the list

    pv_temp_str = pv_temp
    # Convert the flattened list to a string with correct formatting
    # pv_temp_str = ' '.join(map(str, pv_temp))  # Converts to '15 15 20 30'

    print(pv_temp_str)
    # Use the formatted string in your DSS command
    str1 = f'New Tshape.temp npts=24 minterval=60 temp={pv_temp_str}'
    print(str1)
    dss.Text.Command(str1)

    # dss.Text.Command('New Tshape.temp npts=24 minterval=60 temp=' + str(pv_temp))  # change npts for each sim
    createPVs(pv_load_locations, loads_dataframe)
    createSwitchControl()
    dss.Text.Command('solve')

##%%

# TOPOLOGY RE-CONFIGURATION ##########################################################################################
#  randomly select new action for ALL network switches
def flipSwitches():
    for switch in dss.SwtControls.AllNames():
        sw_action = rd.randint(1, 2)  # open(1), close(2)
        dss.SwtControls.Name(switch)  # activate switch online
        # print('current state:', dss.SwtControls.State())
        dss.SwtControls.Action(sw_action)
        dss.SwtControls.State(sw_action)
        dss.SwtControls.Delay(0)
        # print('switched state:', dss.SwtControls.State())

##%%

#  randomly select a switch to flip --> may need to add additional control here
def flipSwitch():
    myswitch = rd.choice(dss.SwtControls.AllNames())
    dss.SwtControls.Name(myswitch)
    if dss.SwtControls.State() == 1:
        dss.SwtControls.Action(2)
        dss.SwtControls.Delay(0)   # add delay before power flow for swt action
    else:
        dss.SwtControls.Action(1)
        dss.SwtControls.Delay(0)

##%%

# GET NET INJECTION DATA ##############################################################################################

def obsLoadPowers(myload):
    dss.Circuit.SetActiveElement(myload)
    powers = dss.CktElement.TotalPowers()
    p = ((powers[0] * 1e3) / Sbase)
    q = ((powers[1] * 1e3) / Sbase)
    return p, q

##%%

def obsPVSysPowers(mypv):
    dss.PVsystems.Name(mypv)
    p = dss.PVsystems.kW()
    q = dss.PVsystems.kvar()
    qpu = ((q * 1e3) / Sbase)
    ppu = ((p * 1e3) / Sbase)
    return ppu, qpu

##%%

def getphaseLabels():
    A = dss.Circuit.AllNodeNamesByPhase(1)
    B = dss.Circuit.AllNodeNamesByPhase(2)
    C = dss.Circuit.AllNodeNamesByPhase(3)
    return A, B, C

##%%

def getphaseVoltages():
    A_vpu = dss.Circuit.AllNodeVmagPUByPhase(1)
    B_vpu = dss.Circuit.AllNodeVmagPUByPhase(2)
    C_vpu = dss.Circuit.AllNodeVmagPUByPhase(3)
    return A_vpu, B_vpu, C_vpu

##%%

# cross-check with above
def getBusVmagsAnglesAllPhases():  # vmags and angles in deg
    A_vpu = []
    A_deg = []
    B_vpu = []
    B_deg = []
    C_vpu = []
    C_deg = []
    for bus in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(bus)
        nodes = dss.Bus.Nodes()  # show connected nodes at active bus
        vpu_angle = dss.Bus.puVmagAngle()
        if len(nodes) == 3:  # 3 phases
            vpuA = vpu_angle[0]
            degA = m.radians(vpu_angle[1])
            A_vpu.append(vpuA)
            A_deg.append(degA)
            vpuB = vpu_angle[2]
            degB = m.radians(vpu_angle[3])
            B_vpu.append(vpuB)
            B_deg.append(degB)
            vpuC = vpu_angle[4]
            degC = m.radians(vpu_angle[5])
            C_vpu.append(vpuC)
            C_deg.append(degC)
        elif len(nodes) == 2:
            if 1 in nodes and 2 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
                vpuB = vpu_angle[2]
                degB = m.radians(vpu_angle[3])
                B_vpu.append(vpuB)
                B_deg.append(degB)
            elif 1 in nodes and 3 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
                vpuC = vpu_angle[2]
                degC = m.radians(vpu_angle[3])
                C_vpu.append(vpuC)
                C_deg.append(degC)
            else:
                vpuB = vpu_angle[0]
                degB = m.radians(vpu_angle[1])
                B_vpu.append(vpuB)
                B_deg.append(degB)
                vpuC = vpu_angle[2]
                degC = m.radians(vpu_angle[3])
                C_vpu.append(vpuC)
                C_deg.append(degC)
        else:  # single phase
            if 1 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
            elif 2 in nodes:
                vpuB = vpu_angle[0]
                degB = m.radians(vpu_angle[1])
                B_vpu.append(vpuB)
                B_deg.append(degB)
            else:
                vpuC = vpu_angle[0]
                degC = m.radians(vpu_angle[1])
                C_vpu.append(vpuC)
                C_deg.append(degC)

    return A_vpu, B_vpu, C_vpu, A_deg, B_deg, C_deg  # return lists of Vmag and phi

##%%

def filterPCE(bus, pce):  # takes pce from active bus, returns list of pce elements per phase and 3 phase
    dss.Circuit.SetActiveBus(bus)
    pce_A = list(filter(lambda x: 's' + bus + 'a' in x, pce))
    pce_B = list(filter(lambda x: 's' + bus + 'b' in x, pce))
    pce_C = list(filter(lambda x: 's' + bus + 'c' in x, pce))
    pce_3 = list(filter(lambda x: bus+'a' not in x and bus+'b' not in x and bus+'c' not in x
                        and 'Capacitor' not in x and 'Regulator' not in x, pce))
    return pce_A, pce_B, pce_C, pce_3

##%%

def phaseNetInjection(pce_phase):
    num_elements = len(pce_phase)
    if num_elements == 1:
        if any('Load' in x for x in pce_phase):
            load = pce_phase[0]  # assume load first in list (always using pce cmd)
            Pload, Qload = obsLoadPowers(load)
            Sload = complex(Pload, Qload)
            Sder = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        elif any('PVSystem' in x for x in pce_phase):
            pv = pce_phase[0].strip('PVSystem.')
            Pder, Qder = obsPVSysPowers(pv)
            Sder = complex(Pder, Qder)
            Sload = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        elif any('Vsource' in x for x in pce_phase):  # source
            Sload = complex(0, 0)
            Sder = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        else:  # any other elements should not appear in pce list
            print('PCE contains additional element per phase: pass')
            pass

    elif num_elements == 2:
        load = pce_phase[0]  # assume load first in list (always using pce cmd)
        Pload, Qload = obsLoadPowers(load)
        Sload = complex(Pload, Qload)
        pv = pce_phase[1].strip('PVSystem.')
        Pder, Qder = obsPVSysPowers(pv)
        Sder = complex(Pder, Qder)
        net = Sload - Sder
        p = net.real
        q = net.imag
        return p, q

    else:
        print('More than 2 PCE elements per phase')  # not counting Capacitors, etc.
        pass

##%%

def PCE(pce):
    if not pce:
        net = complex(0, 0)
        p = net.real
        q = net.imag
    else:
        p, q = phaseNetInjection(pce)
    return p, q

##%%

def busNetInjection(bus, pce, nodes):
    dss.Circuit.SetActiveBus(bus)
    pce_a, pce_b, pce_c, pce_3 = filterPCE(bus, pce)
    if len(pce_3) == 0 and len(nodes) == 3:  # three single phase nodes at bus
        p_a, q_a = PCE(pce_a)
        p_b, q_b = PCE(pce_b)
        p_c, q_c = PCE(pce_c)
    elif len(pce_3) == 0 and len(nodes) == 2:  # two single phase nodes at bus
        if 1 in nodes and 3 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b = 'dne'
            q_b = 'dne'  # indicates missing phase on bus
            p_c, q_c = PCE(pce_c)
        elif 1 in nodes and 2 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b, q_b = PCE(pce_b)
            p_c = 'dne'
            q_c = 'dne'
        else:
            p_a = 'dne'
            q_a = 'dne'
            p_b, q_b = PCE(pce_b)
            p_c, q_c = PCE(pce_c)
    elif len(pce_3) == 0 and len(nodes) == 1:  # one single phase node at bus
        if 1 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b = 'dne'
            q_b = 'dne'
            p_c = 'dne'
            q_c = 'dne'
        elif 2 in nodes:
            p_a = 'dne'
            q_a = 'dne'
            p_b, q_b = PCE(pce_b)
            p_c = 'dne'
            q_c = 'dne'
        else:
            p_a = 'dne'
            q_a = 'dne'
            p_b = 'dne'
            q_b = 'dne'
            p_c, q_c = PCE(pce_c)
    else:
        p,q = PCE(pce_3)
        p_a = p
        p_b = p
        p_c = p
        q_a = q
        q_b = q
        q_c = q
    # print('phase a:', p_a, q_a)
    # print('phase b:', p_b, q_b)
    # print('phase c:', p_c, q_c)
    return p_a, p_b, p_c, q_a, q_b, q_c

##%%

def getNodalInfo():
    Pa = []
    Pb = []
    Pc = []
    Qa = []
    Qb = []
    Qc = []
    for bus in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(bus)
        bus_nodes = dss.Bus.Nodes()
        # num_bus_nodes = dss.Bus.NumNodes()
        pce = dss.Bus.AllPCEatBus()
        pa, pb, pc, qa, qb, qc = busNetInjection(bus, pce, bus_nodes)
        if pa == 'dne':
            pass
        else:
            Pa.append(pa)
        if qa == 'dne':
            pass
        else:
            Qa.append(qa)
        if pb == 'dne':
            pass
        else:
            Pb.append(pb)
        if qb == 'dne':
            pass
        else:
            Qb.append(qb)
        if pc == 'dne':
            pass
        else:
            Pc.append(pc)
        if qc == 'dne':
            pass
        else:
            Qc.append(qc)

    return Pa, Qa, Pb, Qb, Pc, Qc

# %%

def runSimulation():
    run123bus(pv_loads)
    dss.Text.Command('Set voltagebases=[115.0, 4.16, 0.48]')
    dss.Text.Command('calcv')
    dss.Text.Command('Set mode=daily number=1')
    dss.Solution.StepSizeMin(60)  # time step hourly
    dss.Text.Command('Set hour=0')
    a_lab, b_lab, c_lab = getphaseLabels()

    Pa_data = []
    Pb_data = []
    Pc_data = []
    Qa_data = []
    Qb_data = []
    Qc_data = []
    Va_mag = []
    Vb_mag = []
    Vc_mag = []
    Va_angle = []
    Vb_angle = []
    Vc_angle = []
    X = []
    Y = []

    # run time series simulation
    for i in range(num_steps_D1):  # default = num_points
        print('step:', i)
        if i >= 1:
            load_mult = round(rd.uniform(0.9, 1.4), 2)  # randomize load multiplier up to x2
            dss.Text.Command('Set Loadmult=' + str(load_mult))
        else:
            pass
        dss.Text.Command('set ControlMode=OFF')  # enables 7 reg contols, trafo taps, switch control, Cap banks (all control)
        dss.Solution.Solve()
        dss.Solution.FinishTimeStep()

        # dss power flow solution
        a_vpu, b_vpu, c_vpu, a_ang, b_ang, c_ang = getBusVmagsAnglesAllPhases()

        # net injections
        pa_net, qa_net, pb_net, qb_net, pc_net, qc_net = getNodalInfo()
        Pa_data.append(pa_net)
        Pb_data.append(pb_net)
        Pc_data.append(pc_net)
        Qa_data.append(qa_net)
        Qb_data.append(qb_net)
        Qc_data.append(qc_net)
        Va_mag.append(a_vpu)
        Vb_mag.append(b_vpu)
        Vc_mag.append(c_vpu)
        Va_angle.append(a_ang)
        Vb_angle.append(b_ang)
        Vc_angle.append(c_ang)

        # MIMO in/out
        inputs = pa_net + qa_net + pb_net + qb_net + pc_net + qc_net
        # outputs = a_vpu + a_ang + b_vpu + b_ang + c_vpu + c_ang
        outputs = a_vpu + b_vpu + c_vpu  # v mags only

        X.append(inputs)
        Y.append(outputs)

        # flip switch if multiple of int
        if i % sw_num_D1 == 0:
            flipSwitch()
        else:
            pass

    return (Pa_data, Pb_data, Pc_data, Qa_data, Qb_data, Qc_data, Va_mag, Vb_mag, Vc_mag,
            Va_angle, Vb_angle, Vc_angle, a_lab, b_lab, c_lab, X, Y)


if __name__ == '__main__':
    (pa, qa, pb, qb, pc, qc, va, vb, vc, va_ang, vb_ang, vc_ang, a_label, b_label, c_label, X_in,
    Y_out) = runSimulation()

# %%
