# src/utils.py

import math as m
import random as rd
import opendssdirect as dss
from opendssdirect.utils import run_command

#  convert strings in bus names to node numbers for pv installation
def convertchars(pv_buses):
    buses = []
    for load in pv_buses:
        if "s" in load:
            load = load.replace("s", "")
        else:
            pass
        if "a" in load:
            load = load.replace("a", ".1")
            buses.append(load)
        elif "b" in load:
            load = load.replace("b", ".2")
            buses.append(load)
        elif "c" in load:
            load = load.replace("c", ".3")
            buses.append(load)
        else:
            buses.append(load)
    return buses


#  create random pvs at bus locations, set to pf=0.95 for Q injs
def createPVs(pvloads, loadsdf):
    loads = convertchars(pvloads)
    for pvload, load in zip(pvloads, loads):
        for index, row in loadsdf.iterrows():
            if pvload == index:
                kV = row.kV
                pv_size = rd.uniform(0.9, 1.4)
                kVA = round((row.kVABase * pv_size), 5)
                Pmpp = round((kVA * 0.95), 5)  # 95% rated real power
                if load.isnumeric():
                    phases = 3
                else:
                    phases = 1
                run_command(
                    "New PVSystem.pv"
                    + pvload
                    + " phases="
                    + str(phases)
                    + " bus1="
                    + load
                    + " kV="
                    + str(kV)
                    + " kVA="
                    + str(kVA)
                    + " irradiance=1 Pmpp="
                    + str(Pmpp)
                    + " conn=wye temperature=25 PF=0.95"
                    " effcurve=PV_eff P-TCurve=power_temp Daily=irrad TDaily=temp %cutin=0.05 %cutout=0.05"
                )
            else:
                pass



# def obsLoadPowers(myload, Sbase):
#     dss.Circuit.SetActiveElement(myload)
#     powers = dss.CktElement.TotalPowers()
#     p = (powers[0] * 1e3) / Sbase
#     q = (powers[1] * 1e3) / Sbase
#     return p, q

# GET NET INJECTION DATA ##############################################################################################


def obsLoadPowers(myload, Sbase=1e6):
    dss.Circuit.SetActiveElement(myload)
    powers = dss.CktElement.TotalPowers()
    p = (powers[0] * 1e3) / Sbase
    q = (powers[1] * 1e3) / Sbase
    return p, q


# def obsPVSysPowers(mypv, Sbase):
#     dss.PVsystems.Name(mypv)
#     p = dss.PVsystems.kW()
#     q = dss.PVsystems.kvar()
#     qpu = (q * 1e3) / Sbase
#     ppu = (p * 1e3) / Sbase
#     return ppu, qpu


def obsPVSysPowers(mypv, Sbase=1e6):
    dss.PVsystems.Name(mypv)
    p = dss.PVsystems.kW()
    q = dss.PVsystems.kvar()
    qpu = (q * 1e3) / Sbase
    ppu = (p * 1e3) / Sbase
    return ppu, qpu


def getphaseLabels():
    A = dss.Circuit.AllNodeNamesByPhase(1)
    B = dss.Circuit.AllNodeNamesByPhase(2)
    C = dss.Circuit.AllNodeNamesByPhase(3)
    return A, B, C


def getphaseVoltages():
    A_vpu = dss.Circuit.AllNodeVmagPUByPhase(1)
    B_vpu = dss.Circuit.AllNodeVmagPUByPhase(2)
    C_vpu = dss.Circuit.AllNodeVmagPUByPhase(3)
    return A_vpu, B_vpu, C_vpu


# cross-check with above
def getBusVmagsAnglesAllPhases():  # vmags and angles in deg
    A_vpu = []
    A_deg = []
    B_vpu = []
    B_deg = []
    C_vpu = []
    C_deg = []
    for bus in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(bus)
        nodes = dss.Bus.Nodes()  # show connected nodes at active bus
        vpu_angle = dss.Bus.puVmagAngle()
        if len(nodes) == 3:  # 3 phases
            vpuA = vpu_angle[0]
            degA = m.radians(vpu_angle[1])
            A_vpu.append(vpuA)
            A_deg.append(degA)
            vpuB = vpu_angle[2]
            degB = m.radians(vpu_angle[3])
            B_vpu.append(vpuB)
            B_deg.append(degB)
            vpuC = vpu_angle[4]
            degC = m.radians(vpu_angle[5])
            C_vpu.append(vpuC)
            C_deg.append(degC)
        elif len(nodes) == 2:
            if 1 in nodes and 2 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
                vpuB = vpu_angle[2]
                degB = m.radians(vpu_angle[3])
                B_vpu.append(vpuB)
                B_deg.append(degB)
            elif 1 in nodes and 3 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
                vpuC = vpu_angle[2]
                degC = m.radians(vpu_angle[3])
                C_vpu.append(vpuC)
                C_deg.append(degC)
            else:
                vpuB = vpu_angle[0]
                degB = m.radians(vpu_angle[1])
                B_vpu.append(vpuB)
                B_deg.append(degB)
                vpuC = vpu_angle[2]
                degC = m.radians(vpu_angle[3])
                C_vpu.append(vpuC)
                C_deg.append(degC)
        else:  # single phase
            if 1 in nodes:
                vpuA = vpu_angle[0]
                degA = m.radians(vpu_angle[1])
                A_vpu.append(vpuA)
                A_deg.append(degA)
            elif 2 in nodes:
                vpuB = vpu_angle[0]
                degB = m.radians(vpu_angle[1])
                B_vpu.append(vpuB)
                B_deg.append(degB)
            else:
                vpuC = vpu_angle[0]
                degC = m.radians(vpu_angle[1])
                C_vpu.append(vpuC)
                C_deg.append(degC)

    return A_vpu, B_vpu, C_vpu, A_deg, B_deg, C_deg  # return lists of Vmag and phi


# TOPOLOGY RE-CONFIGURATION ##########################################################################################
#  randomly select new action for ALL network switches
def flipSwitches():
    for switch in dss.SwtControls.AllNames():
        sw_action = rd.randint(1, 2)  # open(1), close(2)
        dss.SwtControls.Name(switch)  # activate switch online
        # print('current state:', dss.SwtControls.State())
        dss.SwtControls.Action(sw_action)
        dss.SwtControls.State(sw_action)
        dss.SwtControls.Delay(0)
        # print('switched state:', dss.SwtControls.State())


#  randomly select a switch to flip --> may need to add additional control here
def flipSwitch():
    myswitch = rd.choice(dss.SwtControls.AllNames())
    dss.SwtControls.Name(myswitch)
    if dss.SwtControls.State() == 1:
        dss.SwtControls.Action(2)
        dss.SwtControls.Delay(0)  # add delay before power flow for swt action
    else:
        dss.SwtControls.Action(1)
        dss.SwtControls.Delay(0)


def getBusVmagsAnglesAllPhases():
    A_vpu, A_deg, B_vpu, B_deg, C_vpu, C_deg = [], [], [], [], [], []
    for bus in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(bus)
        nodes = dss.Bus.Nodes()
        vpu_angle = dss.Bus.puVmagAngle()
        if len(nodes) == 3:
            A_vpu.append(vpu_angle[0])
            A_deg.append(m.radians(vpu_angle[1]))
            B_vpu.append(vpu_angle[2])
            B_deg.append(m.radians(vpu_angle[3]))
            C_vpu.append(vpu_angle[4])
            C_deg.append(m.radians(vpu_angle[5]))
        elif len(nodes) == 2:
            if 1 in nodes and 2 in nodes:
                A_vpu.append(vpu_angle[0])
                A_deg.append(m.radians(vpu_angle[1]))
                B_vpu.append(vpu_angle[2])
                B_deg.append(m.radians(vpu_angle[3]))
            elif 1 in nodes and 3 in nodes:
                A_vpu.append(vpu_angle[0])
                A_deg.append(m.radians(vpu_angle[1]))
                C_vpu.append(vpu_angle[2])
                C_deg.append(m.radians(vpu_angle[3]))
            else:
                B_vpu.append(vpu_angle[0])
                B_deg.append(m.radians(vpu_angle[1]))
                C_vpu.append(vpu_angle[2])
                C_deg.append(m.radians(vpu_angle[3]))
        elif len(nodes) == 1:
            if 1 in nodes:
                A_vpu.append(vpu_angle[0])
                A_deg.append(m.radians(vpu_angle[1]))
            elif 2 in nodes:
                B_vpu.append(vpu_angle[0])
                B_deg.append(m.radians(vpu_angle[1]))
            else:
                C_vpu.append(vpu_angle[0])
                C_deg.append(m.radians(vpu_angle[1]))
    return A_vpu, B_vpu, C_vpu, A_deg, B_deg, C_deg


# def phaseNetInjection(pce_phase,
#                       Sbase=1e6):
#     num_elements = len(pce_phase)
#     if num_elements == 1:
#         if "Load" in pce_phase[0]:
#             Pload, Qload = obsLoadPowers(pce_phase[0], Sbase)
#             Sload = complex(Pload, Qload)
#             Sder = complex(0, 0)
#             net = Sload - Sder
#             return net.real, net.imag
#         elif "PVSystem" in pce_phase[0]:
#             Pder, Qder = obsPVSysPowers(pce_phase[0].replace("PVSystem.", ""), Sbase)
#             Sder = complex(Pder, Qder)
#             Sload = complex(0, 0)
#             net = Sload - Sder
#             return net.real, net.imag
#     elif num_elements == 2:
#         Pload, Qload = obsLoadPowers(pce_phase[0], Sbase)
#         Pder, Qder = obsPVSysPowers(pce_phase[1].replace("PVSystem.", ""), Sbase)
#         Sload = complex(Pload, Qload)
#         Sder = complex(Pder, Qder)
#         net = Sload - Sder
#         return net.real, net.imag

#     return 0, 0


def phaseNetInjection(pce_phase):
    num_elements = len(pce_phase)
    if num_elements == 1:
        if any("Load" in x for x in pce_phase):
            load = pce_phase[0]  # assume load first in list (always using pce cmd)
            Pload, Qload = obsLoadPowers(load)
            Sload = complex(Pload, Qload)
            Sder = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        elif any("PVSystem" in x for x in pce_phase):
            pv = pce_phase[0].strip("PVSystem.")
            Pder, Qder = obsPVSysPowers(pv)
            Sder = complex(Pder, Qder)
            Sload = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        elif any("Vsource" in x for x in pce_phase):  # source
            Sload = complex(0, 0)
            Sder = complex(0, 0)
            net = Sload - Sder
            p = net.real
            q = net.imag
            return p, q
        else:  # any other elements should not appear in pce list
            print("PCE contains additional element per phase: pass")
            pass

    elif num_elements == 2:
        load = pce_phase[0]  # assume load first in list (always using pce cmd)
        Pload, Qload = obsLoadPowers(load)
        Sload = complex(Pload, Qload)
        pv = pce_phase[1].strip("PVSystem.")
        Pder, Qder = obsPVSysPowers(pv)
        Sder = complex(Pder, Qder)
        net = Sload - Sder
        p = net.real
        q = net.imag
        return p, q

    else:
        print("More than 2 PCE elements per phase")  # not counting Capacitors, etc.
        pass


# def filterPCE(bus, pce):
#     # This function filters the power conversion elements (PCE) for each phase at the bus
#     dss.Circuit.SetActiveBus(bus)
#     pce_A = [x for x in pce if "a" in x]
#     pce_B = [x for x in pce if "b" in x]
#     pce_C = [x for x in pce if "c" in x]
#     pce_3 = [x for x in pce if "a" not in x and "b" not in x and "c" not in x]
#     return pce_A, pce_B, pce_C, pce_3


def filterPCE(
    bus, pce
):  # takes pce from active bus, returns list of pce elements per phase and 3 phase
    dss.Circuit.SetActiveBus(bus)
    pce_A = list(filter(lambda x: "s" + bus + "a" in x, pce))
    pce_B = list(filter(lambda x: "s" + bus + "b" in x, pce))
    pce_C = list(filter(lambda x: "s" + bus + "c" in x, pce))
    pce_3 = list(
        filter(
            lambda x: bus + "a" not in x
            and bus + "b" not in x
            and bus + "c" not in x
            and "Capacitor" not in x
            and "Regulator" not in x,
            pce,
        )
    )
    return pce_A, pce_B, pce_C, pce_3


def PCE(pce):
    if not pce:
        net = complex(0, 0)
        p = net.real
        q = net.imag
    else:
        p, q = phaseNetInjection(pce)
    return p, q


def busNetInjection(bus, pce, nodes):
    dss.Circuit.SetActiveBus(bus)
    pce_a, pce_b, pce_c, pce_3 = filterPCE(bus, pce)
    print(f"pce_A = {pce_a}")
    print(f"pce_B = {pce_b}")
    print(f"pce_C = {pce_c}")
    print(f"pce_3 = {pce_3}")
    if len(pce_3) == 0 and len(nodes) == 3:  # three single phase nodes at bus
        p_a, q_a = PCE(pce_a)
        p_b, q_b = PCE(pce_b)
        p_c, q_c = PCE(pce_c)
    elif len(pce_3) == 0 and len(nodes) == 2:  # two single phase nodes at bus
        if 1 in nodes and 3 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b = "dne"
            q_b = "dne"  # indicates missing phase on bus
            p_c, q_c = PCE(pce_c)
        elif 1 in nodes and 2 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b, q_b = PCE(pce_b)
            p_c = "dne"
            q_c = "dne"
        else:
            p_a = "dne"
            q_a = "dne"
            p_b, q_b = PCE(pce_b)
            p_c, q_c = PCE(pce_c)
    elif len(pce_3) == 0 and len(nodes) == 1:  # one single phase node at bus
        if 1 in nodes:
            p_a, q_a = PCE(pce_a)
            p_b = "dne"
            q_b = "dne"
            p_c = "dne"
            q_c = "dne"
        elif 2 in nodes:
            p_a = "dne"
            q_a = "dne"
            p_b, q_b = PCE(pce_b)
            p_c = "dne"
            q_c = "dne"
        else:
            p_a = "dne"
            q_a = "dne"
            p_b = "dne"
            q_b = "dne"
            p_c, q_c = PCE(pce_c)
    else:
        p, q = PCE(pce_3)
        p_a = p
        p_b = p
        p_c = p
        q_a = q
        q_b = q
        q_c = q
        # print('phase a:', p_a, q_a)
        # print('phase b:', p_b, q_b)
        # print('phase c:', p_c, q_c)
        
    # print(
    #     f"p = {p}\n"
    #     f"q = {q}"
    # )

    return p_a, p_b, p_c, q_a, q_b, q_c


def getNodalInfo():
    Pa = []
    Pb = []
    Pc = []
    Qa = []
    Qb = []
    Qc = []
    for bus in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(bus)
        bus_nodes = dss.Bus.Nodes()
        # num_bus_nodes = dss.Bus.NumNodes()
        pce = dss.Bus.AllPCEatBus()
        pa, pb, pc, qa, qb, qc = busNetInjection(bus, pce, bus_nodes)
        if pa == "dne":
            pass
        else:
            Pa.append(pa)
        if qa == "dne":
            pass
        else:
            Qa.append(qa)
        if pb == "dne":
            pass
        else:
            Pb.append(pb)
        if qb == "dne":
            pass
        else:
            Qb.append(qb)
        if pc == "dne":
            pass
        else:
            Pc.append(pc)
        if qc == "dne":
            pass
        else:
            Qc.append(qc)

    return Pa, Qa, Pb, Qb, Pc, Qc


# def busNetInjection(bus, pce, nodes):
#     # This function calculates the net injection at a bus for each phase
#     pce_A, pce_B, pce_C, pce_3 = filterPCE(bus, pce)
#     print(f"pce_A = {pce_A}")
#     print(f"pce_B = {pce_B}")
#     print(f"pce_C = {pce_C}")
#     print(f"pce_3 = {pce_3}")

#     if len(pce_3) == 0 and len(nodes) == 3:  # three single-phase nodes at the bus
#         p_a, q_a = PCE(pce_A)
#         p_b, q_b = PCE(pce_B)
#         p_c, q_c = PCE(pce_C)
#     elif len(pce_3) == 0 and len(nodes) == 2:  # two single-phase nodes at the bus
#         if 1 in nodes and 3 in nodes:
#             p_a, q_a = PCE(pce_A)
#             p_b, q_b = "dne", "dne"  # Phase not existing
#             p_c, q_c = PCE(pce_C)
#         elif 1 in nodes and 2 in nodes:
#             p_a, q_a = PCE(pce_A)
#             p_b, q_b = PCE(pce_B)
#             p_c, q_c = "dne", "dne"
#     elif len(pce_3) == 0 and len(nodes) == 1:  # one single-phase node at the bus
#         if 1 in nodes:
#             p_a, q_a = PCE(pce_A)
#             p_b, q_b, p_c, q_c = "dne", "dne", "dne", "dne"
#         elif 2 in nodes:
#             p_a, q_a = "dne", "dne"
#             p_b, q_b = PCE(pce_B)
#             p_c, q_c = "dne", "dne"
#     else:
#         p, q = PCE(pce_3)
#         p_a = p_b = p_c = p
#         q_a = q_b = q_c = q

#     print(f"p = {p}\n q = {q}")
#     return p_a, p_b, p_c, q_a, q_b, q_c
