# src/data_loader.py

import pandas as pd
from pathlib import Path
import numpy as np  # <-- Add this import
import opendssdirect as dss
from opendssdirect.utils import run_command

data_path = Path("./data/supplied-by-daniel/123Bus")


# def importPVData():
#     mypvdata = pd.read_csv(
#         data_path / "27MW_PV_5Min.csv",
#         parse_dates=["LocalTime"],
#         index_col=["LocalTime"],
#     )
#     mypvdata = mypvdata.resample("60min").asfreq()
#     mypvdata = mypvdata.interpolate(method="linear")
#     mypvdata.drop(mypvdata.tail(1).index, inplace=True)
#     data = mypvdata["2006-05-01":"2006-05-01"]
#     data = data.reset_index(drop=True)
#     df_scaled = data.copy()
#     column = "Power(kW)"
#     df_scaled[column] = df_scaled[column] / df_scaled[column].abs().max()
#     pv_time_series = df_scaled[["Power(kW)"]].to_numpy()
#     return pv_time_series


def importPVData():
    # mypvdata = pd.read_csv(data_path + r'\27MW_PV_5Min.csv', parse_dates=['LocalTime'], index_col=['LocalTime'])
    mypvdata = pd.read_csv(
        data_path / "27MW_PV_5Min.csv",
        parse_dates=["LocalTime"],
        index_col=["LocalTime"],
    )
    mypvdata = mypvdata.resample("60min").asfreq()
    mypvdata = mypvdata.interpolate(method="linear")
    mypvdata.drop(mypvdata.tail(1).index, inplace=True)
    data = mypvdata["2006-05-01":"2006-05-01"]  # 1 day
    data = data.reset_index(drop=True)
    df_scaled = data.copy()
    column = "Power(kW)"
    df_scaled[column] = df_scaled[column] / df_scaled[column].abs().max()
    pv_time_series = df_scaled[["Power(kW)"]].to_numpy()
    return pv_time_series


# def upSampleLoadShapesAndTemps(df):
#     df["LocalTime"] = pd.to_datetime(df["LocalTime"])
#     df.set_index("LocalTime", inplace=True)
#     df = df.resample("60min").asfreq()
#     df = df.interpolate(method="linear")
#     df = df["2006-05-01":"2006-05-01"]
#     df = df.reset_index(drop=True)
#     return df


def upSampleLoadShapesAndTemps(df):
    df["LocalTime"] = pd.to_datetime(
        df["LocalTime"]
    )  # interp misses last hour of data set!
    df.set_index("LocalTime", inplace=True)
    df = df.resample("60min").asfreq()
    df = df.interpolate(method="linear")
    df = df["2006-05-01":"2006-05-01"]  # 1 day
    df = df.reset_index(drop=True)
    return df


# def buildTempCurves():
#     pv_temps_hourly_year_path = data_path / "dallas_tx_pv_temp_60min.csv"
#     pv_temps_hourly_year = pd.read_csv(pv_temps_hourly_year_path, parse_dates=True)
#     pv_temp_summer = upSampleLoadShapesAndTemps(pv_temps_hourly_year)
#     pv_temp_arr = pv_temp_summer.to_numpy()
#     pv_temp = np.transpose(pv_temp_arr)
#     return pv_temp


def buildTempCurves():
    # pv_temps_hourly_year = pd.read_csv(data_path + r'\dallas_tx_pv_temp_60min.csv', parse_dates=True)
    # Construct the full path for the CSV file using pathlib
    pv_temps_hourly_year_path = data_path / "dallas_tx_pv_temp_60min.csv"

    # Read the CSV file using the updated path
    pv_temps_hourly_year = pd.read_csv(pv_temps_hourly_year_path, parse_dates=True)

    pv_temp_summer = upSampleLoadShapesAndTemps(pv_temps_hourly_year)
    pv_temp_arr = pv_temp_summer.to_numpy()
    pv_temp = np.transpose(pv_temp_arr)
    return pv_temp


# def buildLoadshapes(pv_time_series):
#     loadshape1_path = data_path / "Loadshape1.csv"
#     loadshape2_path = data_path / "Loadshape2.csv"
#     loadshape3_path = data_path / "Loadshape3.csv"

#     loadshape1 = pd.read_csv(loadshape1_path, parse_dates=True)
#     loadshape2 = pd.read_csv(loadshape2_path, parse_dates=True)
#     loadshape3 = pd.read_csv(loadshape3_path, parse_dates=True)

#     loadshape1_summer = upSampleLoadShapesAndTemps(loadshape1)
#     loadshape2_summer = upSampleLoadShapesAndTemps(loadshape2)
#     loadshape3_summer = upSampleLoadShapesAndTemps(loadshape3)

#     loadshape_1 = loadshape1_summer.to_numpy()
#     loadshape_2 = loadshape2_summer.to_numpy()
#     loadshape_3 = loadshape3_summer.to_numpy()

#     return loadshape_1, loadshape_2, loadshape_3


def buildLoadshapes(
    pv_time_series,
    num_steps_D1=24,
    sw_num_D1=12,
    step_size=60,
    Sbase=1e6,
    num_pvs=20,
    pv_loads=[
        "s106b",
        "s109a",
        "s11a",
        "s87b",
        "s66c",
        "s85c",
        "s53a",
        "s71a",
        "s49c",
        "s30c",
        "s83c",
        "s47",
        "s59b",
        "s64b",
        "s75c",
        "s98a",
        "s35a",
        "s28a",
        "s100c",
        "s37a",
    ],
):
    # loadshape1 = pd.read_csv(data_path + r'\Loadshape1.csv', parse_dates=True)
    # loadshape2 = pd.read_csv(data_path + r'\Loadshape2.csv', parse_dates=True)
    # loadshape3 = pd.read_csv(data_path + r'\Loadshape3.csv', parse_dates=True)

    loadshape1_path = data_path / "Loadshape1.csv"
    loadshape2_path = data_path / "Loadshape2.csv"
    loadshape3_path = data_path / "Loadshape3.csv"

    # Read the CSV files using the updated paths
    loadshape1 = pd.read_csv(loadshape1_path, parse_dates=True)
    loadshape2 = pd.read_csv(loadshape2_path, parse_dates=True)
    loadshape3 = pd.read_csv(loadshape3_path, parse_dates=True)

    loadshape1_summer = upSampleLoadShapesAndTemps(loadshape1)
    loadshape2_summer = upSampleLoadShapesAndTemps(loadshape2)
    loadshape3_summer = upSampleLoadShapesAndTemps(loadshape3)

    loadshape_1 = loadshape1_summer.to_numpy()
    loadshape_2 = loadshape2_summer.to_numpy()
    loadshape_3 = loadshape3_summer.to_numpy()

    run_command("New Loadshape.lshape_1")
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_1)
    dss.LoadShape.QMult(loadshape_1)

    run_command("New Loadshape.lshape_2")
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_2)
    dss.LoadShape.QMult(loadshape_2)

    run_command("New Loadshape.lshape_3")
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(loadshape_3)
    dss.LoadShape.QMult(loadshape_3)

    # PV loadshape
    run_command("New Loadshape.irrad")
    dss.LoadShape.Npts(num_steps_D1)
    dss.LoadShape.MinInterval(step_size)
    dss.LoadShape.PMult(pv_time_series)
