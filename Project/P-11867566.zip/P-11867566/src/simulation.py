# src/simulation.py

# Import necessary functions from other modules
from src.data_loader import importPVData, buildTempCurves, buildLoadshapes
from src.utils import createPVs

import random as rd
import numpy as np
import opendssdirect as dss
from opendssdirect.utils import run_command
from pathlib import Path

Sbase = 1e6
step_size = 60
num_steps_D1 = 24  # one day

master_path = Path("./data/supplied-by-daniel/123Bus")
master_path_str = str(master_path / "IEEE123Master.dss")


# def load123bus():
#     dss.Text.Command("ClearAll")
#     run_command(f"Redirect '{master_path_str}'")
#     dss.Loads.Status(3)
#     dss.Text.Command("set ControlMode=OFF")
#     dss.Text.Command("solve")


def load123bus():
    dss.Text.Command("ClearAll")
    # run_command("Compile 'E:\\OpenDSS\\123Bus\\IEEE123Master.dss'")
    # Use the path in the run_command function
    run_command(f"Redirect '{master_path_str}'")
    dss.Loads.Status(3)  # response to load mult
    dss.Text.Command(
        "set ControlMode=OFF"
    )  # disable vreg, cap banks, etc for voltage swing
    dss.Text.Command("solve")  # solve ss circuit


# def disableCaps():
#     for cap in dss.Capacitors.AllNames():
#         dss.Circuit.SetActiveElement("Capacitor." + cap)
#         dss.CktElement.Enabled(0)


def disableCaps():
    for cap in dss.Capacitors.AllNames():
        dss.Circuit.SetActiveElement("Capacitor." + cap)
        dss.CktElement.Enabled(0)


# def buildXYs():
#     run_command("New XYCurve.power_temp")
#     temp_xarr = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
#     power_yarr = np.array(
#         [1.04, 1.03, 1.02, 1.01, 1.01, 1.0, 0.99, 0.97, 0.89, 0.8, 0.75, 0.7, 0.65]
#     )
#     dss.XYCurves.Npts(13)
#     dss.XYCurves.XArray(temp_xarr)
#     dss.XYCurves.YArray(power_yarr)

#     run_command("New XYCurve.PV_eff")
#     eff_xarr = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
#     eff_yarr = np.array([0.75, 0.78, 0.8, 0.83, 0.86, 0.89, 0.93, 0.95, 0.97, 0.99])
#     dss.XYCurves.Npts(10)
#     dss.XYCurves.XArray(eff_xarr)
#     dss.XYCurves.YArray(eff_yarr)


def buildXYs():
    # PV For Pmpp at 25 deg celcius max efficiency
    run_command("New XYCurve.power_temp")
    temp_xarr = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
    power_yarr = np.array(
        [1.04, 1.03, 1.02, 1.01, 1.01, 1.0, 0.99, 0.97, 0.89, 0.8, 0.75, 0.7, 0.65]
    )
    dss.XYCurves.Npts(13)
    dss.XYCurves.XArray(temp_xarr)
    dss.XYCurves.YArray(power_yarr)

    # PV efficiency curve (all PVs)
    run_command("New XYCurve.PV_eff")
    eff_xarr = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    eff_yarr = np.array([0.75, 0.78, 0.8, 0.83, 0.86, 0.89, 0.93, 0.95, 0.97, 0.99])
    dss.XYCurves.Npts(10)
    dss.XYCurves.XArray(eff_xarr)
    dss.XYCurves.YArray(eff_yarr)


def assignLoadShapes():
    count = 1
    for name in dss.Loads.AllNames():
        dss.Loads.Name(name)  # activate load
        if count == 1:
            dss.Loads.Daily("lshape_1")
        elif count == 2:
            dss.Loads.Daily("lshape_2")
        else:
            dss.Loads.Daily("lshape_3")
            # reset counter
        if count > 3:
            count = 1
        else:
            count += 1


# def createSwitchControl():
#     dss.Text.Command("New swtcontrol.sw2 SwitchedObj=line.sw2 SwitchedTerm=1")
#     dss.Text.Command("New swtcontrol.sw4 SwitchedObj=line.sw4 SwitchedTerm=1")
#     dss.Text.Command("New swtcontrol.sw5 SwitchedObj=line.sw5 SwitchedTerm=1")
#     dss.Text.Command("New swtcontrol.sw7 SwitchedObj=line.sw7 SwitchedTerm=1")
#     dss.Text.Command("New swtcontrol.sw8 SwitchedObj=line.sw8 SwitchedTerm=1")


def createSwitchControl():
    # configure random set of 5 sw ctrls
    dss.Text.Command("New swtcontrol.sw2 SwitchedObj=line.sw2 SwitchedTerm=1")
    dss.Text.Command("New swtcontrol.sw4 SwitchedObj=line.sw4 SwitchedTerm=1")
    dss.Text.Command("New swtcontrol.sw5 SwitchedObj=line.sw5 SwitchedTerm=1")
    dss.Text.Command("New swtcontrol.sw7 SwitchedObj=line.sw7 SwitchedTerm=1")
    dss.Text.Command("New swtcontrol.sw8 SwitchedObj=line.sw8 SwitchedTerm=1")


# build circuit with DERs
def run123bus(pv_load_locations):
    pv_data = importPVData()
    load123bus()
    loads_dataframe = dss.utils.loads_to_dataframe()
    buildXYs()
    buildLoadshapes(pv_data)
    assignLoadShapes()
    pv_temp = buildTempCurves()

    # # Assuming pv_temp is a nested list, flatten it
    # # For example, if pv_temp is [[15, 15, 20, 30]], you want [15, 15, 20, 30]
    # if isinstance(pv_temp, list) and len(pv_temp) == 1:
    #     pv_temp = pv_temp[0]  # Flatten the list

    # pv_temp_str = pv_temp
    # # Convert the flattened list to a string with correct formatting
    # # pv_temp_str = ' '.join(map(str, pv_temp))  # Converts to '15 15 20 30'

    # print(pv_temp_str)
    # # Use the formatted string in your DSS command
    # str1 = f"New Tshape.temp npts=24 minterval=60 temp={pv_temp_str}"

    # Check if pv_temp is a list of lists and flatten it
    if isinstance(pv_temp, list) and len(pv_temp) == 1:
        pv_temp = pv_temp[0]  # Flatten the list

    # Convert the flattened list to a space-separated string
    pv_temp_str = ' '.join(map(str, pv_temp))  # Convert the list to a string with space-separated values

    print(pv_temp_str)
    
    str1 = f"New Tshape.temp npts=24 minterval=60 temp={pv_temp_str}"
    # Now use the formatted string in your OpenDSS command
    
    print(str1)

    dss.Text.Command(str1)

    # dss.Text.Command('New Tshape.temp npts=24 minterval=60 temp=' + str(pv_temp))  # change npts for each sim
    createPVs(pv_load_locations, loads_dataframe)
    createSwitchControl()
    dss.Text.Command("solve")
